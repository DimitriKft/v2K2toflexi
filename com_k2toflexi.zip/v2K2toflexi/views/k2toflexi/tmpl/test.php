<?php
echo "�a marche?)";