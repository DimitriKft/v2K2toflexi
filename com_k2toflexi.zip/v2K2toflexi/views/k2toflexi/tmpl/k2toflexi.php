<?php
/**
 * @version		1.0
* @package		Joomla
* @subpackage	k2toflexi
* @copyright	(C) 2017 Com'3Elles. All right reserved
* @license GNU/GPL v2
*/

// no direct access
defined('_JEXEC') or die('Restricted access');