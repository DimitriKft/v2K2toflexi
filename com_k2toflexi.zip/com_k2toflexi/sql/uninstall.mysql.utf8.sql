DROP TABLE IF EXISTS `#__k2toflexi_log`;
DROP TABLE IF EXISTS `#__k2toflexi_tags`;
DROP TABLE IF EXISTS `#__k2toflexi_items`;
DROP TABLE IF EXISTS `#__k2toflexi_attachments`;
DROP TABLE IF EXISTS `#__k2toflexi_categories`;
DROP TABLE IF EXISTS `#__k2toflexi_extra_fields_groups`;
DROP TABLE IF EXISTS `#__k2toflexi_extra_fields`;
DROP TABLE IF EXISTS `#__k2toflexi_select`;

